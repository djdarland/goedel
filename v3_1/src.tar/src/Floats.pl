:- module('Floats', []).

:- op(500, yfx, and).
:- op(400, yfx, or).

